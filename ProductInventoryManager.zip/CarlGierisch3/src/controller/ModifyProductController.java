package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;


/**
 * ModifyProductController class. Controls the Modify Product screen.
 */
public class ModifyProductController implements Initializable {

    /**
     * The selectedProduct
     */
    private static Product selectedProduct;

    /**
     * The idTXT TextField
     */
    @FXML
    private TextField idTXT;

    /**
     * The nameTXT TextField
     */
    @FXML
    private TextField nameTXT;

    /**
     * The invTXT TextField
     */
    @FXML
    private TextField invTXT;

    /**
     * The priceTXT TextField
     */
    @FXML
    private TextField priceTXT;

    /**
     * The maxTXT TextField
     */
    @FXML
    private TextField maxTXT;

    /**
     * The minTXT TextField
     */
    @FXML
    private TextField minTXT;

    /**
     * The partsTable TableView
     */
    @FXML
    private TableView<Part> partsTable;

    /**
     * The partIDCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> partIDCol;

    /**
     * The partNameCol TableColumn
     */
    @FXML
    private TableColumn<Part, String> partNameCol;

    /**
     * The partInventoryLevelCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> partInventoryLevelCol;

    /**
     * The partPriceCol TableColumn
     */
    @FXML
    private TableColumn<Part, Double> partPriceCol;

    /**
     * The selectedTable TableView
     */
    @FXML
    private TableView<Part> selectedTable;

    /**
     * The selectedIDCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> selectedIDCol;

    /**
     * The selectedNameCol TableColumn
     */
    @FXML
    private TableColumn<Part, String> selectedNameCol;

    /**
     * The selectedInventoryLevelCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> selectedInventoryLevelCol;

    /**
     * The selectedPriceCol TableColumn
     */
    @FXML
    private TableColumn<Part, Double> selectedPriceCol;

    /**
     * The partSearch TextField
     */
    @FXML
    private TextField partSearch;

    /**
     * The selected parts list for the product
     */
    private ObservableList<Part> selectedPartsList = FXCollections.observableArrayList();

    /**
     * initialize method. Starts when Modify Product opens up.
     * <p><b>RUNTIME ERROR - I was getting a null pointer exception on initialize method and the screen wouldn't load to modify a table.
     * After trying various ways to receive the selected part, I realized that my modifyProduct.fxml wasn't set up correctly. I added the parts and products tables.
     * Once the tables were added to modifyProduct.fxml, I was able to use partsTable.setItems and selectedTable.setItems to populate the parts and products in the tables.</b></p>
     *
     * @param url
     * @param resourceBundle
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        partsTable.setItems(Inventory.getAllParts());
        selectedPartsList = Product.getAllAssociatedParts(selectedProduct);
        selectedTable.setItems(selectedPartsList);


        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        selectedIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        selectedNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        selectedInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        selectedPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        idTXT.setText(String.valueOf(selectedProduct.getId()));
        nameTXT.setText(selectedProduct.getName());
        invTXT.setText(String.valueOf(selectedProduct.getStock()));
        priceTXT.setText(String.valueOf(selectedProduct.getPrice()));
        maxTXT.setText(String.valueOf(selectedProduct.getMax()));
        minTXT.setText(String.valueOf(selectedProduct.getMin()));
    }

    /**
     * onSave method. This method saves the product to inventory.
     *
     * @param actionEvent
     */
    public void onSave(ActionEvent actionEvent) {
        try {
            int id = Integer.parseInt(idTXT.getText());
            String name = (nameTXT.getText());
            double price = Double.parseDouble(priceTXT.getText());
            int stock = Integer.parseInt(invTXT.getText());
            int min = Integer.parseInt(minTXT.getText());
            int max = Integer.parseInt(maxTXT.getText());

            if (min >= max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Min value must be less than Max value.");
                alert.showAndWait();
                return;
            }

            if (!(min <= stock && stock <= max)) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Inventory amount must be between min and max.");
                alert.showAndWait();
                return;
            }
            Inventory.deleteProduct(selectedProduct);
            Inventory.addProduct(new Product(id, name, price, stock, min, max, selectedPartsList));


            Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1200, 800);
            stage.setTitle("Back to Main Screen");
            stage.setScene(scene);
            stage.show();
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Inappropriate Data Entered. Please check each field.");
            alert.show();

        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("An IO Error has occurred");
            alert.show();
        }
    }

    /**
     * onCancel method. This method returns to the Main Screen without modifying product.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Back to Main Screen");
        stage.setScene(scene);
        stage.show();
    }


    /**
     * onAdd method. Adds part to the shown parts to include in the product.
     *
     * @param actionEvent
     */
    public void onAdd(ActionEvent actionEvent) {
        Part selectedPart = partsTable.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No Part Selected");
            alert.show();
            return;
        }

        selectedPartsList.add(selectedPart);

    }

    /**
     * onRemove method. Removes parts from shown parts to include in product.
     *
     * @param actionEvent
     */
    public void onRemove(ActionEvent actionEvent) {
        Part selectedPart = selectedTable.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No Part Selected");
            alert.show();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to remove this part?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            selectedPartsList.remove(selectedPart);
        }
    }

    /**
     * onPartSearch method. Searches parts in the parts list using search field.
     *
     * @param actionEvent
     */
    public void onPartSearch(ActionEvent actionEvent) {
        String partSearched = (partSearch.getText());

        ObservableList<Part> parts = searchByPartName(partSearched);

        if (parts.size() == 0) {
            try {
                int partId = Integer.parseInt(partSearched);
                Part p = getAPartWithId(partId);
                if (p != null) {
                    parts.add(p);
                }
            } catch (NumberFormatException e) {
                //e.printStackTrace();
            }
        }

        if (parts.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No Match Found");
            alert.showAndWait();

        } else {
            partsTable.setItems(parts);
        }

    }

    /**
     * searchByPartName method. Checks to see if searched part matches any parts in the list and returns any matching parts.
     *
     * @param partialName
     * @return namedParts list
     */
    private ObservableList<Part> searchByPartName(String partialName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (Part p : allParts) {
            if (p.getName().toLowerCase().contains(partialName.toLowerCase())) {
                namedParts.add(p);
            }
        }

        return namedParts;
    }

    /**
     * getAPartWithId method. Returns a part with a matching ID to what was input in search field.
     *
     * @param partId
     * @return part p
     */
    private Part getAPartWithId(int partId) {

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (int i = 0; i < allParts.size(); i++) {
            Part p = allParts.get(i);
            if (p.getId() == partId) {
                return p;
            }
        }

        return null;
    }

    /**
     * receiveSelectedProduct method. This method receives the selected part from main menu so it can be modified.
     *
     * @param product
     */
    public static void receiveSelectedProduct(Product product) {
        selectedProduct = product;
    }
}
