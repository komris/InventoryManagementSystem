package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * MainController class
 * This represents the controller for the main screen
 */
public class MainController implements Initializable {

    /**
     * The partSearch TextField
     */
    @FXML
    private TextField partSearch;

    /**
     * The productSearch TextField
     */
    @FXML
    private TextField productSearch;

    /**
     * The partsTable Tableview
     */
    @FXML
    private TableView<Part> partsTable;

    /**
     * The partIDCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> partIDCol;

    /**
     * The partNameCol TableColumn
     */
    @FXML
    private TableColumn<Part, String> partNameCol;

    /**
     * The partInventoryLevelCol TableColumn
     */
    @FXML
    private TableColumn<Part, Integer> partInventoryLevelCol;

    /**
     * The partPriceCol TableColumn
     */
    @FXML
    private TableColumn<Part, Double> partPriceCol;

    /**
     * The productsTable TableView
     */
    @FXML
    private TableView<Product> productsTable;

    /**
     * The productIDCol TableColumn
     */
    @FXML
    private TableColumn<Product, Integer> productIDCol;

    /**
     * The productNameCol TableColumn
     */
    @FXML
    private TableColumn<Product, String> productNameCol;

    /**
     * The productInventoryLevelCol TableColumn
     */
    @FXML
    private TableColumn<Product, Integer> productInventoryLevelCol;

    /**
     * The productPriceCol TableColumn
     */
    @FXML
    private TableColumn<Product, Double> productPriceCol;


    /**
     * initiallize method. This method initializes the parts and products tables with inventory.
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        partsTable.setItems(Inventory.getAllParts());
        productsTable.setItems(Inventory.getAllProducts());

        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        productIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


    }

    /**
     * onAddPart method. This method takes user to Add Part menu when button is clicked.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void onAddPart(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/addPart.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Add Part");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * onPartSearch method. This method searches part that was entered in search field.
     *
     * @param actionEvent
     */
    public void onPartSearch(ActionEvent actionEvent) {
        String partSearched = (partSearch.getText());

        ObservableList<Part> parts = searchByPartName(partSearched);

        if (parts.size() == 0) {
            try {
                int partId = Integer.parseInt(partSearched);
                Part p = getAPartWithId(partId);
                if (p != null) {
                    parts.add(p);
                }
            } catch (NumberFormatException e) {
                //e.printStackTrace();
            }
        }

        if (parts.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No Match Found");
            alert.showAndWait();

        } else {
            partsTable.setItems(parts);
        }

    }

    /**
     * searchByPartName method. This method searches part by partial name.
     *
     * @param partialName
     * @return namedParts list
     */
    private ObservableList<Part> searchByPartName(String partialName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (Part p : allParts) {
            if (p.getName().toLowerCase().contains(partialName.toLowerCase())) {
                namedParts.add(p);
            }
        }

        return namedParts;
    }

    /**
     * getAPartWithId method. This method searches for a part based on part Id.
     *
     * @param partId
     * @return the part
     */
    private Part getAPartWithId(int partId) {

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (int i = 0; i < allParts.size(); i++) {
            Part p = allParts.get(i);
            if (p.getId() == partId) {
                return p;
            }
        }

        return null;
    }

    /**
     * onProductSearch method. This method searches for a product in the product table.
     *
     * @param actionEvent
     */
    public void onProductSearch(ActionEvent actionEvent) {
        String productSearched = (productSearch.getText());

        ObservableList<Product> products = searchByProductName(productSearched);

        if (products.size() == 0) {
            try {
                int productId = Integer.parseInt(productSearched);
                Product p = getAProductWithId(productId);
                if (p != null) {
                    products.add(p);
                }
            } catch (NumberFormatException e) {
                //e.printStackTrace();
            }
        }

        if (products.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No Match Found");
            alert.showAndWait();

        } else {
            productsTable.setItems(products);
        }

    }

    /**
     * searchByProductName method. This method searches the parts table by the product name.
     *
     * @param partialName
     * @return namedProducts list
     */
    private ObservableList<Product> searchByProductName(String partialName) {
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (Product p : allProducts) {
            if (p.getName().toLowerCase().contains(partialName.toLowerCase())) {
                namedProducts.add(p);
            }
        }

        return namedProducts;
    }

    /**
     * getAProductWithId method. This method returns a product by searching an Id.
     *
     * @param productId
     * @return the product p
     */
    private Product getAProductWithId(int productId) {

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (int i = 0; i < allProducts.size(); i++) {
            Product p = allProducts.get(i);
            if (p.getId() == productId) {
                return p;
            }
        }

        return null;
    }

    /**
     * onAddProduct method. This method takes user to the Add Product menu.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void onAddProduct(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/addProduct.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Add Product");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * onModifyProduct method. This method takes user to the Modify Product menu.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void onModifyProduct(ActionEvent actionEvent) throws IOException {
        Product selectedProduct = (Product) productsTable.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No Product Selected");
            alert.showAndWait();
            return;
        }

        ModifyProductController.receiveSelectedProduct(selectedProduct);
        Parent root = FXMLLoader.load(getClass().getResource("/view/modifyProduct.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Modify Product");
        stage.setScene(scene);
        stage.show();


    }

    /**
     * onDeleteProduct method. This method deletes the selected product from inventory.
     *
     * @param actionEvent
     */
    public void onDeleteProduct(ActionEvent actionEvent) {
        Product selectedProduct = (Product) productsTable.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No Product Selected");
            alert.showAndWait();
            return;
        }

        if (Product.getAllAssociatedParts(selectedProduct).size() == 0) {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("Are you sure you want to delete selected item?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {

                ModifyProductController.receiveSelectedProduct(selectedProduct);

                Inventory.deleteProduct(selectedProduct);
                productsTable.setItems(Inventory.getAllProducts());
            }
        } else {
            Alert alert2 = new Alert(Alert.AlertType.ERROR);
            alert2.setContentText("You can't delete a product that has associated parts");
            alert2.showAndWait();
        }


    }

    /**
     * onExit method. This method exits the program when exit button is clicked.
     *
     * @param actionEvent
     */
    public void onExit(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to exit the program?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
    }

    /**
     * onModifyPart method. This method takes user to Modify Part menu when button is clicked.
     *
     * @param actionEvent
     */
    public void onModifyPart(ActionEvent actionEvent) {
        try {
            Part selectedPart = (Part) partsTable.getSelectionModel().getSelectedItem();
            if (selectedPart == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("No Part Selected");
                alert.showAndWait();
                return;
            }

            ModifyPartController.receiveSelectedPart(selectedPart);

            Parent root = FXMLLoader.load(getClass().getResource("/view/modifyPart.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1200, 800);
            stage.setTitle("Modify Part");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * onDeletePart method. This method deletes the selected part when button is clicked.
     *
     * @param actionEvent
     */
    public void onDeletePart(ActionEvent actionEvent) {
        Part selectedPart = (Part) partsTable.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No Part Selected");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to delete selected item?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            ModifyPartController.receiveSelectedPart(selectedPart);

            Inventory.deletePart(selectedPart);
            partsTable.setItems(Inventory.getAllParts());
        }


    }
}