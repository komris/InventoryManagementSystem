package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * AddPartController class
 * This class represents the Add Part feature
 */
public class AddPartController implements Initializable {

    /**
     * The addPart AnchorPane
     */
    @FXML
    private AnchorPane addPart;

    /**
     * The inHouse RadioButton
     */
    @FXML
    private RadioButton inHouse;

    /**
     * The source ToggleGroup
     */
    @FXML
    private ToggleGroup source;

    /**
     * The outsourced RadioButton
     */
    @FXML
    private RadioButton outsourced;

    /**
     * The idTXT TextField
     */
    @FXML
    private TextField idTXT;

    /**
     * The partnameTXT TextField
     */
    @FXML
    private TextField partnameTXT;

    /**
     * The partinvTXT TextField
     */
    @FXML
    private TextField partinvTXT;

    /**
     * The partpriceTXT TextField
     */
    @FXML
    private TextField partpriceTXT;

    /**
     * The partmaxTXT TextField
     */
    @FXML
    private TextField partmaxTXT;

    /**
     * The partmahcineidTXT TextField
     */
    @FXML
    private TextField partmachineidTXT;

    /**
     * The machineCompany Label
     */
    @FXML
    private Label machineCompany;

    /**
     * The partminTXT TextField
     */
    @FXML
    private TextField partminTXT;

    /**
     * initialize method. This method initializes when Add Part menu starts.
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**
     * onCancel method. This method takes user back to main screen after hitting cancel.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Back to Main Screen");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * onSave method. This method saves the part to the list when button is clicked.
     *
     * @param actionEvent
     */
    public void onSave(ActionEvent actionEvent) {
        try {

            int id = Inventory.incrementPartID();
            String name = (partnameTXT.getText());
            double price = Double.parseDouble(partpriceTXT.getText());
            int stock = Integer.parseInt(partinvTXT.getText());
            int min = Integer.parseInt(partminTXT.getText());
            int max = Integer.parseInt(partmaxTXT.getText());
            boolean isInHouse;

            if (min >= max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Min value must be less than Max value.");
                alert.showAndWait();
                return;
            }

            if (!(min <= stock && stock <= max)) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Inventory amount must be between min and max.");
                alert.showAndWait();
                return;
            }

            if (inHouse.isSelected()) {
                isInHouse = true;
                int machineId = Integer.parseInt(partmachineidTXT.getText());
                Inventory.addPart(new InHouse(id, name, price, stock, min, max, machineId));
            } else {
                isInHouse = false;
                String companyName = (partmachineidTXT.getText());
                Inventory.addPart(new Outsourced(id, name, price, stock, min, max, companyName));
            }

            Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1200, 800);
            stage.setTitle("Back to Main Screen");
            stage.setScene(scene);
            stage.show();
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Inappropriate Data Entered. Please check each field.");
            alert.show();

        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("An IO Error has occurred");
            alert.show();
        }


    }

    /**
     * onInHouse method. This method sets text to Machine ID when In-House button is clicked.
     *
     * @param actionEvent
     */
    public void onInHouse(ActionEvent actionEvent) {
        machineCompany.setText("Machine ID");
    }

    /**
     * onOutsourced method. This method sets the text to Company name when Outsourced button is clicked.
     *
     * @param actionEvent
     */
    public void onOutsourced(ActionEvent actionEvent) {
        machineCompany.setText("Company Name");
    }
}
