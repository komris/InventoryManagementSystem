package main;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Part;
import model.Product;
/**

 */

/**
 * Main class
 * This class creates an app that manages inventory.
 * <p><b>Javadocs located in javadocs folder</b></p>
 * <p><b>FUTURE ENHANCEMENT - An enhancement to this program would be to keep track of the cost of the goods, in addition to the sales price.
 * You could then track your total inventory value for tax purposes.</b></p>
 */
public class Main extends Application {

    /**
     * start method. Sets the stage for Main Screen.
     *
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
        primaryStage.setTitle("Main Screen");
        primaryStage.setScene(new Scene(root, 1200, 800));
        primaryStage.show();
    }

    /**
     * main method. Sets sample inventory for main screen.
     *
     * @param args
     */
    public static void main(String[] args) {
        InHouse part1 = new InHouse(1, "Tire", 10.0, 3, 0, 100, 25);
        InHouse part2 = new InHouse(3, "Seat", 15.0, 6, 0, 100, 30);

        Product product1 = new Product(2, "Bike", 100.00, 3, 0, 100);

        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addProduct(product1);

        launch(args);
    }


}
