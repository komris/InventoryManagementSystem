package model;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

/**
 * Inventory class
 * this represents the inventory
 */
public class Inventory {

    /**
     * The list of all parts in inventory
     */
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();

    /**
     * The list of all products in inventory
     */
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    /**
     * The ID created for a new part
     */
    public static int newPartID = 3;

    /**
     * incrementPartID. This method increments the part ID by 2.
     *
     * @return the newPartID
     */
    public static int incrementPartID() {
        newPartID = newPartID + 2;
        return newPartID;
    }

    /**
     * The ID created for a new product
     */
    public static int newProductID = 2;

    /**
     * incrementProductID. This method increments the product ID by 2.
     *
     * @return the newProductID
     */
    public static int incrementProductID() {
        newProductID = newProductID + 2;
        return newProductID;
    }

    /**
     * addPart method. This method adds the part to the allParts list.
     *
     * @param newPart
     */
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    /**
     * addProduct method. This method adds the product to the allProducts list.
     *
     * @param newProduct
     */
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**
     * lookupPart method. This method searches for parts in the parts table and returns a part.
     *
     * @param partId
     * @return the part p
     */
    public static Part lookupPart(int partId) {
        ObservableList<Part> allParts = Inventory.getAllParts();

        for (int i = 0; i < allParts.size(); i++) {
            Part p = allParts.get(i);
            if (p.getId() == partId) {
                return p;
            }
        }

        return null;
    }

    /**
     * lookupPart method. This method searches for parts in parts table and returns a list of related parts.
     *
     * @param partName
     * @return the namedParts list
     */
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (Part p : allParts) {
            if (p.getName().toLowerCase().contains(partName.toLowerCase())) {
                namedParts.add(p);
            }
        }

        return namedParts;
    }

    /**
     * lookupProduct method. This method searches for a product in the product table and returns a list.
     *
     * @param productName
     * @return the namedProducts list
     */
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (Product p : allProducts) {
            if (p.getName().toLowerCase().contains(productName.toLowerCase())) {
                namedProducts.add(p);
            }
        }

        return namedProducts;
    }

    /**
     * lookupProduct method. This method searches for a product in the product table and returns a product.
     *
     * @param productId
     * @return the product p
     */
    public static Product lookupProduct(int productId) {
        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (int i = 0; i < allProducts.size(); i++) {
            Product p = allProducts.get(i);
            if (p.getId() == productId) {
                return p;
            }
        }

        return null;
    }

    /**
     * updatePart method. This method updates the selected part in the parts list.
     *
     * @param index
     * @param selectedPart
     */
    public static void updatePart(int index, Part selectedPart) {
        getAllParts().set(index, selectedPart);
    }

    /**
     * updateProduct method. This method updates the product from the products list.
     *
     * @param index
     * @param newProduct
     */
    public static void updateProduct(int index, Product newProduct) {
        getAllProducts().set(index, newProduct);

    }

    /**
     * deletePart method. This method deletes a part from the allParts list.
     *
     * @param selectedPart
     * @return true
     */
    public static boolean deletePart(Part selectedPart) {
        allParts.remove(selectedPart);
        return true;
    }

    /**
     * deleteProduct method. This method deletes a product from the allProducts list.
     *
     * @param selectedProduct
     * @return true
     */
    public static boolean deleteProduct(Product selectedProduct) {
        allProducts.remove(selectedProduct);
        return true;
    }

    /**
     * getAllParts method. This method gets all the parts in the allParts list.
     *
     * @return the allParts list
     */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    /**
     * getAllProducts method. This method gets all the products in the allProducts list.
     *
     * @return
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }


}
