package model;

/**
 * Outsourced class
 * this class represents Outsourced products
 */
public class Outsourced extends Part {
    /**
     * The company name for Outsourced products
     */
    private String companyName;

    /**
     * Outsourced constructor
     *
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param companyName
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     * getCompanyName method. This method gets the companyName.
     *
     * @return the companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * setCompanyName method. this method sets the companyName.
     *
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

}
