package model;

/**
 * InHouse class
 * this class represents In House products.
 */
public class InHouse extends Part {
    /**
     * The machine ID for InHouse products
     */
    private int machineId;

    /**
     * InHouse constructor
     *
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param machineId
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    /**
     * getMachineId method. this method returns the machineId.
     *
     * @return the machineId
     */
    public int getMachineId() {
        return machineId;
    }

    /**
     * setMachineId method. This method sets the machineId.
     *
     * @param machineId
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }

}
