package model;

import controller.ModifyProductController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Product Class
 * This represents the Product
 */
public class Product {

    /**
     * The product id
     */
    private int id;

    /**
     * The product name
     */
    private String name;

    /**
     * The product price
     */
    private double price;

    /**
     * The product inventory(stock)
     */
    private int stock;

    /**
     * The minimum product inventory
     */
    private int min;

    /**
     * The maximum product inventory
     */
    private int max;

    /**
     * The Product's list of associated parts
     */
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    /**
     * Product Constructor without associatedParts
     *
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     * Product Constructor with associatedParts
     *
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param associatedParts
     */
    public Product(int id, String name, double price, int stock, int min, int max, ObservableList<Part> associatedParts) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
        this.associatedParts = associatedParts;

    }

    /**
     * Returns the id
     *
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the id
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the name
     *
     * @return name
     **/
    public String getName() {
        return name;
    }

    /**
     * Sets the name
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the price
     *
     * @return price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price
     *
     * @param price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Returns the inventory(stock)
     *
     * @return
     */
    public int getStock() {
        return stock;
    }

    /**
     * Sets the inventory(stock)
     *
     * @param stock
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Returns the minimum inventory
     *
     * @return min
     */
    public int getMin() {
        return min;
    }

    /**
     * Sets the minimum inventory
     *
     * @param min
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     * Returns the max inventory
     *
     * @return
     */
    public int getMax() {
        return max;
    }

    /**
     * Sets the max inventory
     *
     * @param max
     */
    public void setMax(int max) {
        this.max = max;
    }


    /**
     * addAssociatedPart method. Adds the associated part to the list of associated parts.
     *
     * @param part
     */
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }

    /**
     * deleteAssociatedPart method. Deletes the part from the list of associated parts.
     *
     * @param selectedAssociatedPart
     * @return
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        return associatedParts.remove(selectedAssociatedPart);
    }


    /**
     * Gets All Associated Parts for a product.
     *
     * @param selectedProduct
     * @return the list of associated parts
     */
    public static ObservableList<Part> getAllAssociatedParts(Product selectedProduct) {
        return selectedProduct.associatedParts;
    }


}